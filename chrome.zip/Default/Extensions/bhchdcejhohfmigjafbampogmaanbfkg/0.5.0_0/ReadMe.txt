ua-parser.min.js:
  https://github.com/faisalman/ua-parser-js/releases/tag/1.0.32
